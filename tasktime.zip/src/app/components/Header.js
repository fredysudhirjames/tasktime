
export default function Header() {
	return(
		<header className='min-h-14 py-5 px-6 bg-indigo-400 text-white/60 italic text-center'>
			Space for header elements
		</header>
	)
}
