import { NextResponse } from 'next/server';
import connectDB from '@/app//backend/mongodb';
import Summary from '@/app/backend/model/summary';

export async function GET() {
	await connectDB();
	try {
		const tasksSummary = await Summary.find()
		return NextResponse.json( { summary: tasksSummary } )
	} catch ( error ) {
		console.error( 'Summary fetch failed ', error )
		return NextResponse.json( { error: 'Failed to fetch summary' }, { status: 500 } )
	}
}
